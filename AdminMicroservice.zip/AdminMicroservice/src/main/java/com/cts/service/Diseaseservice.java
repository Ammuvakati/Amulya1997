package com.cts.service;
import com.cts.model.Disease;

public interface Diseaseservice {
	
	//public  Disease addDisease(Disease disease, int fid);

}
