package com.cts.service;

import com.cts.model.AdminEntity;

public interface AdminService {
	
	public AdminEntity getadmin(String uname, String password); 

	
}
