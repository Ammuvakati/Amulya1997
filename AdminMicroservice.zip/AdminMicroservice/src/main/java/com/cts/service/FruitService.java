package com.cts.service;

import com.cts.model.AdminEntity;
import com.cts.model.Fruits;

public interface FruitService {
	
	 public Fruits addFruit(Fruits fruits, int id);

}
