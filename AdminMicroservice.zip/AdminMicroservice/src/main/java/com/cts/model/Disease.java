package com.cts.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="disease")
public class Disease implements Serializable {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int did;
	private String dname;
	private String type;
	private String remedy;
	@ManyToOne
	@JoinColumn(name="admin_id")
	private AdminEntity aid;
	
	public Disease() {
		
	}

	public Disease(int did, String dname, String type, String remedy, AdminEntity aid) {
		this.did = did;
		this.dname = dname;
		this.type = type;
		this.remedy = remedy;
		this.aid = aid;
	}

	public int getDid() {
		return did;
	}

	public void setDid(int did) {
		this.did = did;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getRemedy() {
		return remedy;
	}

	public void setRemedy(String remedy) {
		this.remedy = remedy;
	}

	public AdminEntity getAid() {
		return aid;
	}

	public void setAid(AdminEntity aid) {
		this.aid = aid;
	}

	@Override
	public String toString() {
		return "Disease [did=" + did + ", dname=" + dname + ", type=" + type + ", remedy=" + remedy + ", aid=" + aid
				+ "]";
	}

	
	
	

}
