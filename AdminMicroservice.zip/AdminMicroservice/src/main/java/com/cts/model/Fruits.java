package com.cts.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="fruits")
public class Fruits implements Serializable {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int fid;
	private int price;
	private String fname;
	private String dname;
	private String description;
    @ManyToOne
    @JoinColumn(name="admin_key")
    private AdminEntity id;


	
	public Fruits()
	{
				
	}
	
	
	public Fruits(int fid, int price, String fname, String dname, String description, AdminEntity id) {
		this.fid = fid;
		this.price = price;
		this.fname = fname;
		this.dname = dname;
		this.description = description;
		this.id = id;
	}


	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public AdminEntity getId() {
		return id;
	}
	public void setId(AdminEntity id) {
		this.id = id;
	}
	
	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "Fruits [fid=" + fid + ", price=" + price + ", fname=" + fname + ", dname=" + dname + ", description="
				+ description + ", id=" + id + "]";
	}


	}
	

	
	

	