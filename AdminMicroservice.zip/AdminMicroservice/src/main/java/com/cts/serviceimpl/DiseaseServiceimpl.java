package com.cts.serviceimpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.AdminEntity;
import com.cts.model.Disease;
import com.cts.model.Fruits;
import com.cts.repository.AdminDao;
import com.cts.repository.DiseaseDao;
import com.cts.service.Diseaseservice;

@Service
public class DiseaseServiceimpl implements Diseaseservice {
	
	@Autowired
	private DiseaseDao diseasedao;
	@Autowired
	private AdminDao admindao;

	public Disease addDisease(Disease disease, int aid) 
	{
		AdminEntity admin = admindao.getOne(aid);
		disease.setAid(admin);
		return diseasedao.save(disease);			
	}


	public List<Disease> getAllDiseases(int aid) {
		
		return diseasedao.findAll();
	}


	public List<Disease> searchfordisease(String dname) {
		
		return diseasedao.findByName(dname);
	}


	public void deletedisease(int did) {
		diseasedao.deleteById(did);
	}

	

	/*public void deleteitem(int fid) {
		
		return diseasedao.deletefruitid(fid);	
		
	}*/

	
		
	}


