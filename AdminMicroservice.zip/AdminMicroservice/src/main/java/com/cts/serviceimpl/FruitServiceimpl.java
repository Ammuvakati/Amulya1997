package com.cts.serviceimpl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.AdminEntity;
import com.cts.model.Fruits;
import com.cts.repository.AdminDao;
import com.cts.repository.FruitDao;
import com.cts.service.FruitService;

@Service
public class FruitServiceimpl implements FruitService {
	
	@Autowired
	private FruitDao fruitdao;
	@Autowired
	private AdminDao admindao;
	
	public Fruits addFruit(Fruits fruits, int id)
	{
		AdminEntity admin= admindao.getOne(id);
		fruits.setId(admin);
		return fruitdao.save(fruits);
	}

	public List<Fruits> getAllFruits(int aid) {
		return fruitdao.findAllById(aid);
	}

	public List<Fruits> searchforfruit(String fname) {
		
		return fruitdao.findByName(fname);
	}

	

	public Fruits updatefruit(int aid, Fruits fruits) {
		
		Fruits fruit = fruitdao.getOne(aid);
		int price=fruits.getPrice();
		fruit.setPrice(price);
		return fruitdao.save(fruit);	
		
	}
	
}



	
	
	


