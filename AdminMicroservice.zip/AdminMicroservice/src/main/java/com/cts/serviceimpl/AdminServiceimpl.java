package com.cts.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cts.model.AdminEntity;
import com.cts.repository.AdminDao;
import com.cts.service.AdminService;

@Service
public class AdminServiceimpl implements AdminService{
	
	@Autowired
	private AdminDao admindao;
	
	

	public AdminEntity addAdmin(AdminEntity admin) {
	
		return admindao.save(admin);
		
		//return "data added";
	}

	

	public List<AdminEntity> getAllAdmin() {
		
		return admindao.findAll();
	}



	public AdminEntity getadmin(String uname, String password) {
		Optional<AdminEntity> a = admindao.findByUsernameAndPassword(uname,password);
		AdminEntity admin = a.orElse(null);
		return admin;
		
}
	
}


	
	

