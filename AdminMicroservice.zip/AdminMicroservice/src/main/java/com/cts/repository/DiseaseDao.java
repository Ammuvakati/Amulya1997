package com.cts.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.model.Disease;


@Repository
public interface DiseaseDao extends JpaRepository<Disease, Integer> {

	@Query(value="FROM Disease where dname like %:dname%")
	public List<Disease> findByName(String dname);

	


	/*@Transactional
    @Modifying
    @Query(value="Delete from disease where fruit_id=:fid",nativeQuery=true)

	public void deletefruitid(int fid)*/
	

  
}
