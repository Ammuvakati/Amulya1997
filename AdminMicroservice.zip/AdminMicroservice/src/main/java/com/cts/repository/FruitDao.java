package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.model.Fruits;

@Repository
public interface FruitDao extends JpaRepository<Fruits, Integer> {

	
	@Query(value="FROM Fruits where fname like %:name%")
    public List<Fruits> findByName(@Param("name") String fname);

	

    @Query(value="SELECT * From fruits where admin_key=:aid",nativeQuery=true)
	public List<Fruits> findAllById(int aid);


}
