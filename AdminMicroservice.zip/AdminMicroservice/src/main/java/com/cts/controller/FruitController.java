package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Fruits;
import com.cts.serviceimpl.FruitServiceimpl;


@RestController
@RequestMapping(value="/admin")
public class FruitController {
	
	
	@Autowired
	private FruitServiceimpl  fruitservice;
	
	@RequestMapping(value="addfruit/{adminid}", method=RequestMethod.POST,produces="application/json")
	public String addFruit(@PathVariable(value="adminid") int id, @RequestBody Fruits fruits)
	{
		 fruitservice.addFruit(fruits,id);
		 return "Fruit Added";
	}
	
	@RequestMapping("getAllFruits/{adminid}")
	public List<Fruits> getAllFruits(@PathVariable(value="adminid") int aid)
	{
		return fruitservice.getAllFruits(aid);
	}
	
	@RequestMapping(value="searchfruit/{fruitname}")
	public List<Fruits> searchforfruit(@PathVariable(value="fruitname") String name)
	{
		return fruitservice.searchforfruit(name);
	}
	
	@RequestMapping(value="updatefruit/{adminid}")
	public Fruits updatefruit(@PathVariable(value="adminid") int aid, @RequestBody Fruits fruits)
	{
		return fruitservice.updatefruit(aid,fruits);
	}
	

	

	


	
}
