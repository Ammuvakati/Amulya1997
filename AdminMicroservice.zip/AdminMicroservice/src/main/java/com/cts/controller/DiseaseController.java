package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Disease;
import com.cts.model.Fruits;
import com.cts.serviceimpl.DiseaseServiceimpl;
@RestController
@RequestMapping("/admin")
public class DiseaseController {
	
	@Autowired
	private DiseaseServiceimpl diseaseservice;
	
	@RequestMapping(value="/adddisease/{adminid}")
	public String addDisease(@PathVariable(value="adminid") int aid, @RequestBody Disease disease)
	{
		diseaseservice.addDisease(disease, aid);
		return "Disease added";	
	}
	
	@RequestMapping("getAllDiseases/{adminid}")
	public List<Disease> getAllDiseases(@PathVariable(value="adminid") int aid)
	{
		return diseaseservice.getAllDiseases(aid);
	}
	@RequestMapping(value="deletedisease/{diseaseid}")
	public void deletedisease(@PathVariable(value="diseaseid") int did)
	{
		diseaseservice.deletedisease(did); 
	}

	
	
	@RequestMapping(value="searchdisease/{diseasename}")
	public List<Disease> searchfordisease(@PathVariable(value="diseasename") String dname)
	{
		return diseaseservice.searchfordisease(dname);
	}
}
