import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Cart } from './cart';
@Injectable({
  providedIn: 'root'
})
export class SellerServiceService {
  private baseUrl= 'http://localhost:9091/searchitem';

  constructor(private http: HttpClient) { }

  getItemsByName(name: String): Observable<any> {

    return this.http.get(`${this.baseUrl}/${name}`);
      }

      addtocart(cart: Cart): Observable<any> {
        return this.http.post('http://localhost:8081/addcart/1001',cart);
      }
       getitemByid(): Observable<any> {
         return this.http.get('http://localhost:8081/getitembyid/1001');
       }
       deleteitemById(): Observable<any> {
         return this.http.get('http://localhost:8081/deleteById/1001')

       }
    
    }
    

