package com.example.springboot.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.springboot.dao.BuyerDao;
import com.example.springboot.entity.Buyer;
import com.example.springboot.entity.ShoppingCart;
import com.example.springboot.entity.Transactions;
import com.example.springboot.service.BuyerService;
import com.example.springboot.service.CartService;

@RestController
@CrossOrigin(origins="*")
//@RequestMapping("/cart")
public class ShoppingCartController 
{
	@Autowired
	private CartService service;
	
	//@Autowired
	//private BuyerService buyerservice;
	
	@PostMapping("addcart/{bid}")
	public  String  addCartItem(@PathVariable(value = "bid") int bid, @RequestBody ShoppingCart cart) 
	{
		//Optional<ShoppingCart> savedItem = service.addCartItem(cartitem,bid);
		//System.out.println("controller");
		//return savedItem.get();
		return service.addcartItem(bid, cart);				
	}
	@RequestMapping("getitembyid/{bid}")
	public List<ShoppingCart> getCartItemById(@PathVariable(value="bid") int bid)
	{
		return service.getCartItembyId(bid);
	}
	
	@RequestMapping("deleteAll")
	public void deleteAllCart()
	{
		service.deleteAllCart();
	}
	

	//deleting item by cartId
	@RequestMapping("deleteById/{bid}")
	public void deleteById(@PathVariable(value="bid") int bid)
	{
	    service. deleteById(bid);
	}
	
    @PostMapping("updatecartbyId/{cartid}")
	public ShoppingCart UpdateCart(@PathVariable( value= "cartid") int cid, @RequestBody ShoppingCart cart)
	{
    	return service.updatecart(cid,cart);
	}
    
    @RequestMapping("checkout/{bid}")
    public void checkout(@PathVariable(value="bid") int bid)
    {
    	service.checkout(bid);
    }
    
    
   
    
	
}

