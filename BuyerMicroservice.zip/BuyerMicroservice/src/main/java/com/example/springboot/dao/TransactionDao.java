package com.example.springboot.dao;

import javax.persistence.JoinColumn;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springboot.entity.Transactions;

public interface TransactionDao extends JpaRepository<Transactions,Integer>{

}
