package com.example.springboot.service;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springboot.dao.BuyerDao;
import com.example.springboot.dao.CartDao;
import com.example.springboot.dao.TransactionDao;
import com.example.springboot.entity.Buyer;
import com.example.springboot.entity.ShoppingCart;
import com.example.springboot.entity.Transactions;

@Service
public class CartService
{
	@Autowired
	private CartDao cartdao;
	@Autowired
	private BuyerDao buyerdao;
	@Autowired
	private TransactionDao transactiondao;
	
	
	
	public String addcartItem(int bid, ShoppingCart cart) 
	{
		Buyer buyer=buyerdao.getOne(bid);
		cart.setBuyer(buyer);
		 cartdao.save(cart);
		 return "itemadded";
	}
	//public void deleteCartItem(int id)
	//{
		//return cartdao.deleteCartItem(id);
	//}
	public void deleteById(int bid) 
	{
		 cartdao.deleteById(bid);
	}
	public List<ShoppingCart> getCartItembyId(int bid) {
		
		return cartdao.findAll();
	}
	public void deleteAllCart() {
		cartdao.deleteAll();
	}
	public ShoppingCart updatecart(Integer cid, ShoppingCart cart)
	{
	
		Optional<ShoppingCart> c=cartdao.findById(cid);
		ShoppingCart cart1=null;
		if(c.isPresent())
		{
			cart1=c.get();
			cart1.setNumberofitems(cart.getNumberofitems());
			return cartdao.save(cart1);	
		}
		return null;
	}
	public Transactions checkout(int bid,Transactions transactions)
	{
		Buyer buyer=buyerdao.getOne(bid);
		transactions.setBuyer(buyer);
	    return transactiondao.save(transactions);
	    
				
	}
	
	
	
	

	
	}

	


