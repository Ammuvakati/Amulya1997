package com.example.springboot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.springboot.entity.Buyer;
import com.example.springboot.entity.ShoppingCart;

@Repository
public interface CartDao extends JpaRepository<ShoppingCart,Integer> 
{
	ShoppingCart save(Buyer buyer);
    @Query(value="SELECT * FROM shoppingcart where buyer_key=:bid",nativeQuery=true)
	List<ShoppingCart> getAllCartitems(int bid);
}

