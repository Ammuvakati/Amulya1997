package com.cts.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.ShoppingCart;
import com.cts.model.Transactions;
import com.cts.model.UserEntity;
import com.cts.repository.CartDao;
import com.cts.repository.Transactiondao;
import com.cts.repository.UserDao;
import com.cts.service.CartService;

@Service
public class CartServiceimpl implements CartService {
	
	@Autowired
	private CartDao cartdao;
	@Autowired
	private UserDao userdao;
	@Autowired
	private Transactiondao transactiondao;

	public String addcartItem(int uid, ShoppingCart cart) {
		UserEntity user = userdao.getOne(uid);
		cart.setUser(user);
		cartdao.save(cart);
		return "item added";
	}

	public List<ShoppingCart> getCartItembyId(int uid) {
		return cartdao.findAll();
	}

	public void deleteAllCart() {
		cartdao.deleteAll();
		
	}

	public ShoppingCart updatecart(int cartid, ShoppingCart cart) {
		
		
		
		Optional<ShoppingCart> c=cartdao.findById(cartid);
		ShoppingCart cart1=null;
		if(c.isPresent())
		{
			cart1=c.get();
			cart1.setNumberofitems(cart.getNumberofitems());
			return cartdao.save(cart1);	
		}
		return null;	
	}

	public void deleteItemById(int cartid) {
		cartdao.deleteById(cartid);
		
		
	}
	
	

	public void checkout(int id, Transactions transactions) {
		
		Optional<UserEntity> user=userdao.findById(id);
		List<ShoppingCart> getAllitems=cartdao.getAllCartitems(id);
		transactions=new Transactions();
		
		transactions.setUser(user.get());
		transactions.setRemarks(transactions.getRemarks());
		transactions.setTransactiontype(transactions.getTransactiontype());
		transactiondao.save(transactions);
		ShoppingCart cart = new ShoppingCart();
        cartdao.delete(cart);
	}
	
	
}

	
	/*public void checkout(int bid,Transactions transactions)
	{
		Optional<Buyer> buyer=buyerdao.findById(bid);
		PurchaseHistory purchasehistory=null;
		//Transactions transactions=null;
		
		List<ShoppingCart> getAllitems=cartdao.getAllCartitems(bid);
		transactions=new Transactions();
		
		transactions.setBuyer(buyer.get());
		transactions.setRemarks(transactions.getRemarks());
		transactions.setTransactionType(transactions.getTransactionType());
		transactiondao.save(transactions);
		
		for(ShoppingCart cart:getAllitems)
		{
			purchasehistory=new PurchaseHistory();
			purchasehistory.setBuyer(buyer.get());
			purchasehistory.setNumberOfItems(cart.getNumberofitems());
			purchasehistory.setRemarks(transactions.getRemarks());
			purchasedao.save(purchasehistory);
			cartdao.delete(cart);
			
			
		}*/
		
		
		
		

	

