package com.cts.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.UserEntity;
import com.cts.repository.UserDao;
import com.cts.service.UserService;

@Service
public class UserServiceimpl implements UserService {
	
	@Autowired
	private UserDao userdao;

	public UserEntity adduser(UserEntity user) {
		
		return userdao.save(user);
	}

	public List<UserEntity> getallusers() {
		return userdao.findAll();
	}

	
}
