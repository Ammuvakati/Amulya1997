package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cts.model.ShoppingCart;

public interface CartDao extends JpaRepository<ShoppingCart, Integer>{
	
	@Query(value="SELECT * FROM cart where user_key=:id",nativeQuery=true)
	List<ShoppingCart> getAllCartitems(int id);

	

	
}
