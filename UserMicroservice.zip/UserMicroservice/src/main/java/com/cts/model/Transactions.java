package com.cts.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "transactions")
public class Transactions implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int transactionid;
	private String transactiontype;
	@CreationTimestamp
	private Date datecreated;
	private String remarks;
	
	@ManyToOne
	@JoinColumn(name="user_key")
	private UserEntity user;

	
	public Transactions() {
		
	}

	
	

	public Transactions(int transactionid, String transactiontype, Date datecreated, String remarks, UserEntity user) {
		this.transactionid = transactionid;
		this.transactiontype = transactiontype;
		this.datecreated = datecreated;
		this.remarks = remarks;
		this.user = user;
	}




	public int getTransactionid() {
		return transactionid;
	}

	public void setTransactionid(int transactionid) {
		this.transactionid = transactionid;
	}

	public String getTransactiontype() {
		return transactiontype;
	}

	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}

	public Date getDatecreated() {
		return datecreated;
	}

	public void setDatecreated(Date datecreated) {
		this.datecreated = datecreated;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	

	public UserEntity getUser() {
		return user;
	}

	public void setUser(UserEntity user) {
		this.user = user;
	}




	@Override
	public String toString() {
		return "Transactions [transactionid=" + transactionid + ", transactiontype=" + transactiontype
				+ ", datecreated=" + datecreated + ", remarks=" + remarks + ", user=" + user + "]";
	}

	

}
