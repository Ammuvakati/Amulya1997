package com.cts.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "cart")
public class ShoppingCart implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cartid;
	private int numberofitems;
	private int price;
	private int fid;
	@ManyToOne
	@JoinColumn(name = "user_key")
	private UserEntity user;
	
	public ShoppingCart() {
		
	}

	public ShoppingCart(int cartid, int numberofitems, int price, int fid, UserEntity user) {
		this.cartid = cartid;
		this.numberofitems = numberofitems;
		this.price = price;
		this.fid = fid;
		this.user = user;
	}

	public int getCartid() {
		return cartid;
	}

	public void setCartid(int cartid) {
		this.cartid = cartid;
	}

	public int getNumberofitems() {
		return numberofitems;
	}

	public void setNumberofitems(int numberofitems) {
		this.numberofitems = numberofitems;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getFid() {
		return fid;
	}

	public void setFid(int fid) {
		this.fid = fid;
	}

	public UserEntity getUser() {
		return user;
	}

	public void setUser(UserEntity user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "ShoppingCart [cartid=" + cartid + ", numberofitems=" + numberofitems + ", price=" + price + ", fid="
				+ fid + ", user=" + user + "]";
	}
	

}
