package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.ShoppingCart;
import com.cts.model.Transactions;
import com.cts.serviceimpl.CartServiceimpl;

@RestController
@RequestMapping(value="/user")
public class CartController {
	
	@Autowired
	private CartServiceimpl cartservice;
	
	@PostMapping("addcart/{uid}")
	public  String  addCartItem(@PathVariable(value = "uid") int uid, @RequestBody ShoppingCart cart) 
	{
		return cartservice.addcartItem(uid, cart);	
	}
	
	@RequestMapping("getcartitembyid/{uid}")
	public List<ShoppingCart> getCartItemById(@PathVariable(value="uid") int uid)
	{
		return cartservice.getCartItembyId(uid);
	}
	
	@DeleteMapping("deletecartbyid/{cartid}")
	public void deleteItemById(@PathVariable(value="cartid") int cartid) {
		cartservice.deleteItemById(cartid);
	}


	@RequestMapping("deleteAll")
	public void deleteAllCart()
	{
		cartservice.deleteAllCart();
	}
	
	@PostMapping("updatecartbyId/{cartid}")
	public ShoppingCart UpdateCart(@PathVariable( value= "cartid") int cartid, @RequestBody ShoppingCart cart)
	{
    	return cartservice.updatecart(cartid,cart);
	}
	

    
    @PostMapping("checkout/{id}")
    public void checkout(@PathVariable(value="id") int id, Transactions transactions)
    {
    	cartservice.checkout(id,transactions);
    }
    


	

}
