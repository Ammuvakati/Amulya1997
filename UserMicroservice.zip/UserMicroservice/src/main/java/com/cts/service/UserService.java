package com.cts.service;

public interface UserService {

}
