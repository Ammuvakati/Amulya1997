export class User {
    id: number;
    username: String;
	password: String;
    email: String;
    location: String;
	mobilenumber: number;
}