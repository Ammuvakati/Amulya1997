import { Component, OnInit } from '@angular/core';
import { Cart } from '../Cart';

import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-displayfruits',
  templateUrl: './displayfruits.component.html',
  styleUrls: ['./displayfruits.component.css']
})
export class DisplayfruitsComponent implements OnInit {

 cartitems: cart = new Cart();
 i: any;
 displaycart: any;

  constructor(private userservice: UserServiceService) { }

  ngOnInit(): void {
  }
  Increment(displaycart: cart, cartid: number)
{
console.log("incre");
displaycart.numberofitems+=1;

}
Decrement(displaycart: cart, cartid: number)
{
  console.log("decre");
  displaycart.numberofitems-=1;
}


}
