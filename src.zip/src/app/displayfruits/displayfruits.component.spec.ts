import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayfruitsComponent } from './displayfruits.component';

describe('DisplayfruitsComponent', () => {
  let component: DisplayfruitsComponent;
  let fixture: ComponentFixture<DisplayfruitsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisplayfruitsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayfruitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
