import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { Disease } from 'src/Disease';
import { Admin } from './Admin';


@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {
  

  constructor(private http: HttpClient) { }

addAdmin (admin: Object): Observable<any> {
  return this.http.post(`http://localhost:8998/admin/addadmin`, admin);
}
loginUserFromRemote(admin: Admin): Observable<any> {
  return this.http.post<any>('http://localhost:8998/admin/login', admin);
}
addFruit (fruits: object, adminid: number): Observable<any> {
  return this.http.post(`http://localhost:8998/admin/addfruit/${adminid}`, fruits);
}
addDisease (disease: object, adminid: number): Observable<any> {
  return this.http.post(`http://localhost:8998/admin/adddisease/${adminid}`,disease)
}
updateFruit (adminid: number, fruit: object): Observable<any> {
  return this.http.put(`http://localhost:8998/admin/updatefruit/${adminid}`, fruit);
}

}