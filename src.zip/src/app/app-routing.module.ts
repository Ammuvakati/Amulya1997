import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplaycartitemsComponent } from './displaycartitems/displaycartitems.component';
import { SearchitemComponent } from './searchitem/searchitem.component';

 



const routes: Routes = [
 {path:'Shoppingcart',component:DisplaycartitemsComponent},
{path:'searchitem',component: SearchitemComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
