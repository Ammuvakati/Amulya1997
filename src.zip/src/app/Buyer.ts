export class Buyer {
     username: String;
	 password: String;
	 email: String;
	 mobileNumber: number
}










