import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-diseasedetails',
  templateUrl: './diseasedetails.component.html',
  styleUrls: ['./diseasedetails.component.css']
})
export class DiseasedetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
