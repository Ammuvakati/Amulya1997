export class Fruit {
    fruitid: number;
    price: number;
    fruitname: String;
	diseasename: String;
	description: String;
    adminid: Number
}