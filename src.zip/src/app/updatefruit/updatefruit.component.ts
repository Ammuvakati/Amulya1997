import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { Fruit } from '../Fruit';

@Component({
  selector: 'app-updatefruit',
  templateUrl: './updatefruit.component.html',
  styleUrls: ['./updatefruit.component.css']
})
export class UpdatefruitComponent implements OnInit {

  fruitid: number;
  adminid: number;
  fruit: Fruit;

  constructor(private route: ActivatedRoute, private router: Router,
     private adminservice: AdminServiceService) { }

  ngOnInit(): void {
    this.fruit = new Fruit();
    this.fruitid = this.route.snapshot.params['adminid'];
  }
  updatefruit() {
    this.adminservice.updateFruit(this.adminid,this.fruit)
    .subscribe(data=>console.log(data), error=>console.log(error));
    this.fruit = new Fruit();
    this.gotoList();
  }
  onSubmit() {
    this.updatefruit();
  }
  gotoList() {
    this.router.navigate(['/fruitss']);
  }

}
