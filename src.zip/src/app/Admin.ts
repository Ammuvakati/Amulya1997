export class Admin {
     id: number;
	 username: String;
	 password: String;
	 email: String
}

