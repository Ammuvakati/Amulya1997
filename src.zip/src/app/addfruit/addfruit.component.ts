import { Component, OnInit } from '@angular/core';
import { Admin } from '../Admin';
import { AdminServiceService } from '../admin-service.service';
import { Fruit } from '../Fruit';


@Component({
  selector: 'app-addfruit',
  templateUrl: './addfruit.component.html',
  styleUrls: ['./addfruit.component.css']
})
export class AddfruitComponent implements OnInit {

  fruits: Fruit = new Fruit();
  
  
  admin: Admin = new Admin();
  constructor(private adminservice: AdminServiceService) { }

  ngOnInit(): void {
  }
  //adminid = this.admin.id;
  adminid: number = 1;
  onSubmit() {
    
    console.log("Fruit added");
    this.adminservice.addFruit(this.fruits, this.adminid).subscribe(fruitdetails=>this.fruits=fruitdetails);
    }

}
