export class Transactions {
    transactionId: number;
	transactionType: String;
	transactionDate: String;
	remarks: String;
}