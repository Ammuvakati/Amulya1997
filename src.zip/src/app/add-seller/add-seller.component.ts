import { Component, OnInit } from '@angular/core';
import { Seller } from '../Seller';
import { SellerserviceService } from '../sellerservice.service';

@Component({
  selector: 'app-add-seller',
  templateUrl: './add-seller.component.html',
  styleUrls: ['./add-seller.component.css']
})
export class AddSellerComponent implements OnInit {

  seller: Seller=new Seller();

  constructor(private sellerservice: SellerserviceService) { }

  ngOnInit(): void {
  }
  addseller(): void {
    // this.submitted=false;
    this.seller=new Seller();
}
save() {

  this.sellerservice.addSeller(this.seller)
  .subscribe(data =>console.log(data),error => console.log(error));
  this.seller=new Seller(); 
}
onSubmit()
{
  //this.submitted =true;
  this.save();

}





}



