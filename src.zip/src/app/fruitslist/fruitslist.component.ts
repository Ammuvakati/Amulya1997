import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AdminServiceService } from '../admin-service.service';
import { Fruit } from '../Fruit';

@Component({
  selector: 'app-fruitslist',
  templateUrl: './fruitslist.component.html',
  styleUrls: ['./fruitslist.component.css']
})
export class FruitslistComponent implements OnInit {

fruit: Observable<Fruit[]>
  constructor(private adminservice: AdminServiceService, private router: Router) { }

  ngOnInit(): void {
  }
  updatefruit(adminid:number) {
    this.router.navigate(['update' , adminid]);
  }
}
