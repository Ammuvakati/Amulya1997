import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdddiseaseComponent } from './adddisease.component';

describe('AdddiseaseComponent', () => {
  let component: AdddiseaseComponent;
  let fixture: ComponentFixture<AdddiseaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdddiseaseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdddiseaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
