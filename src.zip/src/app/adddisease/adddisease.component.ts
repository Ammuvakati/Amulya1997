import { Component, OnInit } from '@angular/core';
import { Disease } from 'src/Disease';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-adddisease',
  templateUrl: './adddisease.component.html',
  styleUrls: ['./adddisease.component.css']
})
export class AdddiseaseComponent implements OnInit {

  disease: Disease = new Disease();
  constructor(private adminservice: AdminServiceService) { }

  ngOnInit(): void {
  }
  adminid: number = 1; 
  onSubmit() {
    console.log("disease added");
    this.adminservice.addDisease(this.disease, this.adminid).subscribe(diseases=>this.disease=diseases);
  }

}
