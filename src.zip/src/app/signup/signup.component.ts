import { Component, OnInit } from '@angular/core';
import { User } from 'src/user';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  user: User = new User();
  constructor(private userservice: UserServiceService) { }

  ngOnInit(): void {
  }
  adduser(): void {
    this.user = new User();
  }
  save() {
    this.userservice.adduser(this.user)
    .subscribe(data =>console.log(data), error => console.log(error));
    this.user = new User();
  }
  onSubmit() {
    console.log("user added");
    this.save();
  }

}
