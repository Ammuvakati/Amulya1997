import { Component, OnInit } from '@angular/core';
import { Admin } from '../Admin';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  admin: Admin = new Admin();

  constructor(private adminservice: AdminServiceService) { }

  ngOnInit(): void {
  }

  addadmin(): void {
    // this.submitted=false;
   this.admin = new Admin();
}

  save() {
    this.adminservice.addAdmin(this.admin)
    .subscribe(data =>console.log(data), error => console.log(error));
    this.admin = new Admin();
  }

  onSubmit() {
    console.log("admin added");
    this.save();
  }

}
