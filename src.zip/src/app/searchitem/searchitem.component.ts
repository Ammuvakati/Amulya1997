import { Component, OnInit } from '@angular/core';
import { Item } from '../Item';
import { SellerServiceService } from '../seller-service.service';

@Component({
  selector: 'app-searchitem',
  templateUrl: './searchitem.component.html',
  styleUrls: ['./searchitem.component.css']
})
export class SearchitemComponent implements OnInit {

  name: String;
  item: Item;
  constructor(private sellerservice: SellerServiceService) { }

  ngOnInit(): void {
    this.name="";
  }
  searchitem() {
  
    this.sellerservice.getItemsByName(this.name).subscribe(Item=>this.item=Item);
    console.log("invoked searchitem()");
   //this.sellerservice.getItemsByName("T").subscribe(items=>{console.log("Item name is:"+items[0].itemname)});
  }
  onSubmit(){
    this.searchitem();
}
}
