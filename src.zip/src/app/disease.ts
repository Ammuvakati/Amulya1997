export class Disease {
    diseaseid: number;
	diseasename: String;
	type: String;
	remedy: String;
    adminid: number;
}