import { Component, OnInit } from '@angular/core';
import { Item } from '../Item';
import { SellerserviceService } from '../sellerservice.service';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit {

  item: Item=new Item();

  constructor(private sellerservice: SellerserviceService) { }

  ngOnInit(): void {
  }
  onSubmit() {
    console.log("item added");
    this.sellerservice.addItem(this.item).subscribe(itemdetails=>this.item=itemdetails);
  }

}
