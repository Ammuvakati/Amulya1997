import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { cart } from './cart';
import { Seller } from './Seller';
@Injectable({
  providedIn: 'root'
})
export class SellerServiceService {
  private baseUrl= 'http://localhost:9091/searchitem';

  constructor(private http: HttpClient) { }

  getItemsByName(name: String): Observable<any> {

    return this.http.get(`${this.baseUrl}/${name}`);
      }

      addtocart(cart: cart): Observable<any> {
        return this.http.post('http://localhost:8081/addcart/1001',cart);
      }
       getitemByid(): Observable<any> {
         return this.http.get('http://localhost:8081/getitembyid/1001');
       }
       deleteitemById( cartId: number): Observable<any> {
         return this.http.delete(`http://localhost:8081/deleteById/${cartId}`);
       }
       addSeller(seller: Object): Observable<any> {
         return this.http.post('htpp://localhost:9091//addseller',seller);
       }
    
    }
    

