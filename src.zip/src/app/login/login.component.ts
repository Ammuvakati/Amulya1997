import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../Admin';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  admin: Admin = new Admin();
  message= " ";
  constructor(private adminservice: AdminServiceService, private router: Router ) { }

  ngOnInit(): void {
  }
  loginadmin() {
    this.adminservice.loginUserFromRemote(this.admin)
    .subscribe(data => {console.log("response received");
                         this.router.navigate(['/loginsuccess'])},
     error =>{ console.log("exception occured");
    this.message = "Bad Credentials, Please enter valid emailid and Password";})                      
    
  }
  signup() {
    this.router.navigate(['/signup'])

  }
 /* loginuser() {
    this.userservice.loginUserFromRemote(this.user)
    .subscribe(data =>{ console.log("response received");
                         this.router.navigate(['/loginsuccess'])},
    error =>{ console.log("exception occured");
    this.message= "Bad Credentials, Please enter valid emailid and Password";})
  }
  signup() {
    this.router.navigate(['/signup'])
  }*/

}
