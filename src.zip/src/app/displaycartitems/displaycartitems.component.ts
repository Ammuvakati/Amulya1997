import { Component, OnInit } from '@angular/core';
import { cart } from '../cart';
import { SellerServiceService } from '../seller-service.service';

@Component({
  selector: 'app-displaycartitems',
  templateUrl: './displaycartitems.component.html',
  styleUrls: ['./displaycartitems.component.css']
})
export class DisplaycartitemsComponent implements OnInit {

  cartitems: cart[];
  i:any;
  constructor(private sellerservice: SellerServiceService) { }

  ngOnInit() {
    this.reloadcart();
        
  }
  reloadcart(){

    this.sellerservice.getitemByid().subscribe(cartitems=>this.cartitems=cartitems);
  }
 /* displaycart() {
    console.log("displaycartitems");
    

  }*/
  deleteitem(i) {
   console.log("itemdeleted");
   this.sellerservice.deleteitemById(i).subscribe(() => this.reloadcart());

 } 

}
