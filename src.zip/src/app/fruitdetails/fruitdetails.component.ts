import { Component, Input, OnInit } from '@angular/core';
import { Cart } from '../Cart';
import { Fruits } from '../Fruits';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-fruitdetails',
  templateUrl: './fruitdetails.component.html',
  styleUrls: ['./fruitdetails.component.css']
})
export class FruitdetailsComponent implements OnInit {

  constructor(private userservice: UserServiceService) { }
 @Input() fruit: Fruits
 cart = new Cart();

  ngOnInit(): void {
  }
  addtocart() {
    console.log("cart item added");
  }
}
