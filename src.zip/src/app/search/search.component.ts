import { Component, OnInit } from '@angular/core';
import { Fruits } from '../Fruits';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  name: any;
  fruit: Fruits;
  constructor(private userservice: UserServiceService) { }

  ngOnInit(): void {
    //this.name="";
  }
  searchFruit() {
    this.userservice.searchForFruit(this.name).subscribe(fruits=>this.fruit=fruits);
  }
  onSubmit() {
    this.searchFruit();
    console.log("search invoked");


  }

}
