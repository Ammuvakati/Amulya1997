import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { ItemdetailsComponent } from './itemdetails/itemdetails.component';
import { DisplaycartitemsComponent } from './displaycartitems/displaycartitems.component';
import { SearchitemComponent } from './searchitem/searchitem.component';
import { BuyerSignupComponent } from './buyer-signup/buyer-signup.component';
import { LoginComponent } from './login/login.component';
import { CheckOutComponent } from './check-out/check-out.component';
 


@NgModule({
  declarations: [
    AppComponent,
    ItemdetailsComponent,
    DisplaycartitemsComponent,
    SearchitemComponent,
    BuyerSignupComponent,
    LoginComponent,
    CheckOutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
