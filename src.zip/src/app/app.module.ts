import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { ItemdetailsComponent } from './itemdetails/itemdetails.component';
import { DisplaycartitemsComponent } from './displaycartitems/displaycartitems.component';
import { SearchitemComponent } from './searchitem/searchitem.component';
import { SignUpComponent } from './sign-up/sign-up.component';
 


@NgModule({
  declarations: [
    AppComponent,
    ItemdetailsComponent,
    DisplaycartitemsComponent,
    SearchitemComponent,
    SignUpComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
