import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SignupComponent } from './signup/signup.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AddfruitComponent } from './addfruit/addfruit.component';
import { AdddiseaseComponent } from './adddisease/adddisease.component';
import { LoginComponent } from './login/login.component';
import { FruitslistComponent } from './fruitslist/fruitslist.component';
import { UpdatefruitComponent } from './updatefruit/updatefruit.component';

const routes: Routes = [
  {path: 'signup' ,component: SignupComponent },
  {path: 'login' , component: LoginComponent},
  {path: 'addfruit' ,component: AddfruitComponent },
  {path: 'adddisease' ,component: AdddiseaseComponent},
  {path: 'signup' , component: SignupComponent},
  {path: 'update/:adminid', component: UpdatefruitComponent}
]
@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    SignupComponent,
    LoginComponent, 
    AddfruitComponent,
    AdddiseaseComponent,
    FruitslistComponent,
    UpdatefruitComponent,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
