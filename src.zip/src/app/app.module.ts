import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http'

import { AppComponent } from './app.component';
//import { NavbarComponent } from './navbar/navbar.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginsuccessComponent } from './loginsuccess/loginsuccess.component';
import { FruitdetailsComponent } from './fruitdetails/fruitdetails.component';
import { DiseasedetailsComponent } from './diseasedetails/diseasedetails.component';
import { SearchComponent } from './search/search.component';
import { DisplayfruitsComponent } from './displayfruits/displayfruits.component';
//import { SearchComponent } from './search/search.component';

const routes: Routes = [
  {path: 'signup' ,component: SignupComponent },
  {path: 'login' ,component: LoginComponent },
  {path: 'loginsuccess' ,component: LoginsuccessComponent },
  {path: 'signup' , component: SignupComponent },
  {path: 'search' , component: SearchComponent},
  {path: 'cart' , component: DisplayfruitsComponent}
 //{path: 'search' , component: FruitdetailsComponent },



]
  
@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    LoginComponent,
    LoginsuccessComponent,
    FruitdetailsComponent,
    DiseasedetailsComponent,
    SearchComponent,
    DisplayfruitsComponent,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
