import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../user';
import { Cart } from './Cart';


@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  private baseurl = 'http://localhost:8998/admin/searchfruit';

  constructor(private http: HttpClient ) { }


  adduser(user: object): Observable<any> {
    return this.http.post(`http://localhost:8999/user/adduser`, user);
  }
  loginUserFromRemote(user: User): Observable<any> {
    return this.http.post<any>('http://localhost:8999/user/login', user);
  }
 searchForFruit(name: any): Observable<any> {
   return this.http.get(`${this.baseurl}/${name}`);
 }
 searchForDisease(name: String): Observable<any> {
   return this.http.get(`http://localhost:8998/admin/searchdisease/${name}`);
 }
 addtocart(cart: Cart,bid:String): Observable<any> {
  return this.http.post(`http://localhost:9091/addcart/${bid}`,cart);
}

}
