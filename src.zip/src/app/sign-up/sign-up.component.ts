import { Component, OnInit } from '@angular/core';
import { Seller } from '../Seller';
import { SellerServiceService } from '../seller-service.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  seller: Seller=new Seller();
  constructor(private sellerservice: SellerServiceService) { }

  ngOnInit(): void {
  
  }
  addseller(): void {
      // this.submitted=false;
      this.seller=new Seller();
  }
  save() {

    this.sellerservice.addSeller(this.seller)
    .subscribe(data =>console.log(data),error => console.log(error));
    this.seller=new Seller(); 
  }
  onSubmit()
  {
    //this.submitted =true;
    this.save();

  }





}
