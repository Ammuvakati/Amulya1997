export class Cart {
    cartid: number;
	numberofitems: number;
	price: number;
	fruitid: number;
	user: number;
}