export class Fruits {
    fruitid: number;
	price: number;
	fruitname: String;
	diseasename: String;
	description: String;
    adminid: number;
}